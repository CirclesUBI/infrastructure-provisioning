var AWS = require('aws-sdk')
// rekognition is not available in eu-central-1
var cognitoISP = new AWS.CognitoIdentityServiceProvider({apiVersion: '2016-04-18'})

exports.handler = (event) => {
  console.log('test deploy')
  var params = {
    GroupName: 'circles-basic-user-group',
    UserPoolId: event.userPoolId,
    Username: event.userName
  }

  cognitoISP.adminAddUserToGroup(params, (err, data) => {
    if (err) console.error(err)
    else {
      const response = {
        statusCode: 200,
        body: JSON.stringify(event.userName + ' added by Lambda!')
      }
      return response
    }
  })
}
