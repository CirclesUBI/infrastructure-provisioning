var AWS = require('aws-sdk')
var cognitoISP = new AWS.CognitoIdentityServiceProvider({apiVersion: '2016-04-18'})
var sns = new AWS.SNS({apiVersion: '2010-03-31'})
var pg = require('pg')
const client = new pg.Client()
client.connect()

function prepareResponse (resultJson, err) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': true
  }

  if (err) {
    return {
      statusCode: 500,
      headers: headers,
      body: JSON.stringify({
        status: false
      })
    }
  } else {
    return {
      statusCode: 200,
      headers: headers,
      body: JSON.stringify(resultJson)
    }
  }
}

function saveUserRecord (event) {
  console.log('saveUserRecord')
  const timestamp = Date.now()
  const queryString = `INSERT INTO "user" ("display_name", "email", "profile_pic_url", "created_at", "updated_at") VALUES ('${event.request.userAttributes.name}', '${event.request.userAttributes.email}', '${event.request.userAttributes.picture}', TO_TIMESTAMP('${timestamp}'), TO_TIMESTAMP('${timestamp}'));`

  return new Promise((resolve, reject) => { 
    client.query(queryString, (err, data) => {
      client.end()
      if (err) reject(err)
      else {
        console.log('finished saveUserRecord')
        resolve(data)
      }
    })
  })
}

function createSNSEndpoint (event) {
  console.log('createSNSEndpoint')
  let token = event.request.userAttributes['custom:deviceId']
  console.log(token)
  var snsParams = {
    PlatformApplicationArn: process.env.ANDROID_ARN,
    Token: event.request.userAttributes['custom:deviceId']
  }
  return new Promise((resolve, reject) => {
    sns.createPlatformEndpoint(snsParams, (err, data) => {
      console.log(err, data)
      if (err) reject(err)
      else {
        console.log('finished createSNSEndpoint')
        resolve(data)
      }
    })
  })
}

function addToCognitoGroup (event) {
  console.log('addToCognitoGroup')
  const groupName = 'circles-basic-user-group'
  var params = {
    GroupName: groupName,
    UserPoolId: event.userPoolId,
    Username: event.userName
  }
  return new Promise((resolve, reject) => {
    resolve(true)
    cognitoISP.adminAddUserToGroup(params, (err, data) => {
      if (err) reject(err)
      else {
        console.log('finished addToCognitoGroup')
        resolve(data)
      }
    })
  })
}

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmtpyEventLoop = false

  Promise.all([
    saveUserRecord(event),
    createSNSEndpoint(event),
    addToCognitoGroup(event)
  ]).then((resultsArray) => {
    console.log(resultsArray)
    callback(null, resultsArray)
  }
  ).catch((err) => {
    console.log(err)
    callback(err, null)
  })
}
